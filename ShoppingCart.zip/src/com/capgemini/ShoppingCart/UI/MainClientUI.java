package com.capgemini.ShoppingCart.UI;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.ShoppingCart.Bean.Item;
import com.capgemini.ShoppingCart.Service.CustomerOrderServiceImp;
import com.capgemini.ShoppingCart.Utility.ItemRepositories;

/**
 * 
 * @author Raone10
 * @version 1.0 This is MainUI class taking the inputs.
 *
 */
public class MainClientUI {

	static CustomerOrderServiceImp service=new CustomerOrderServiceImp();
	static Scanner scanner=new Scanner(System.in);

	void Register() {
		System.out.println("Enter Name");
		String name=scanner.next();
		System.out.println("Enter Phone Number");
		long phone=scanner.nextLong();
		String choice;
		
		System.out.println(phone+"Registered Succesfully.!!");
		
		System.out.println("1. Placing the Order \n 2.Display the Cart \n 3.Exit");
		int option=scanner.nextInt();
		do {
		switch(option)
		{
		case 1: placeOrder();break;
		case 2: displayCart();break;
		case 3: System.exit(0);
		default:System.out.println("Enter Option 1 to 3  only");
		}
		System.out.println("Press Y to continue");
		 choice=scanner.next();
	}while(choice.equalsIgnoreCase(choice));
		
	}
	
	private void displayCart() {
		
	
	}






	private void placeOrder() {
		ItemRepositories itemrepo=new ItemRepositories();
		Map<Integer, Item> items=itemrepo.getItems();
		double price=0;
		
		Iterator<Integer> iterator=items.keySet().iterator();
		while(iterator.hasNext()) {
			int id=iterator.next();
			Item itemdata=items.get(id);
		    System.out.println(id+" :"+itemdata);
		}
		System.out.println("Enter Id");
		int id1=scanner.nextInt();
		System.out.println("Enter Quantity");
		int quantity=scanner.nextInt();
		
		while(iterator.hasNext()) {
			int id=iterator.next();
			if(id1==id) 
			price=items.get(id).getPrice();		
		}
	        double amount=quantity*(price);
	        
	        Order order=new Order(id,)
	    
		
		
	}






	public static void main(String[] args) {
		MainClientUI clientUI=new MainClientUI();
		System.out.println("Welcome to the Product Management System");
		System.out.println("1. Register \n 0.Exit");
		int choice=scanner.nextInt();
		
		switch(choice)
		{
		case 1: clientUI.Register();
				break;
		case 0 : System.exit(0);
		default:System.out.println("Please enter the Choice 1 or 0");
				
		}

	}

}
