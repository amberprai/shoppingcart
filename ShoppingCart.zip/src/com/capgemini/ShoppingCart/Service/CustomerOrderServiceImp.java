package com.capgemini.ShoppingCart.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.capgemini.ShoppingCart.Bean.Item;
import com.capgemini.ShoppingCart.Bean.Order;
import com.capgemini.ShoppingCart.DAO.ItemDao;
import com.capgemini.ShoppingCart.DAO.ItemDaoImp;

public class CustomerOrderServiceImp implements CustomerOrderService {
	int id=100;
       	ItemDao itemDao=new ItemDaoImp();
	       Order order=new Order();
	       Map<Integer, Order> orderMap=new TreeMap<Integer, Order>();

	@Override
	public boolean addToCart(Order item) {
		int orderId= id+1;
		item.setOrderId(orderId);
		
		Order status=orderMap.put(orderId,item);
		
		if(status !=null)
			return true;
		else 
			return false;
	}

	@Override
	public List<Order> printOrderedItems() {
		List<Order> orderedList=new ArrayList<>();
		Collection<Order> collection=orderMap.values();
		orderedList.addAll(collection);
		return orderedList;
	}

	@Override
	public List<Item> getItems() {
		
		List<Item> itemlist=new ArrayList<>();
		Collection<Item> collection=itemDao.getItems().values();
		itemlist.addAll(collection);
		return itemlist;
	}


	

}
