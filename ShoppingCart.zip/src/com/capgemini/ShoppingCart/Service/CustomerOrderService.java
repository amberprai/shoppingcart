package com.capgemini.ShoppingCart.Service;

import java.util.List;

import com.capgemini.ShoppingCart.Bean.Item;
import com.capgemini.ShoppingCart.Bean.Order;

public interface CustomerOrderService {
	boolean addToCart(Order item);
	List<Order> printOrderedItems();
	public List<Item> getItems();
	
}